import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'home_page_widget.dart' show HomePageWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class HomePageModel extends FlutterFlowModel<HomePageWidget> {
  ///  Local state fields for this page.

  int? loopCount = 0;

  ///  State fields for stateful widgets in this page.

  final unfocusNode = FocusNode();
  // State field(s) for FullNames widget.
  FocusNode? fullNamesFocusNode;
  TextEditingController? fullNamesTextController;
  String? Function(BuildContext, String?)? fullNamesTextControllerValidator;
  // State field(s) for Email widget.
  FocusNode? emailFocusNode;
  TextEditingController? emailTextController;
  String? Function(BuildContext, String?)? emailTextControllerValidator;
  DateTime? datePicked;
  // State field(s) for ContactNumbers widget.
  FocusNode? contactNumbersFocusNode;
  TextEditingController? contactNumbersTextController;
  String? Function(BuildContext, String?)?
      contactNumbersTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    unfocusNode.dispose();
    fullNamesFocusNode?.dispose();
    fullNamesTextController?.dispose();

    emailFocusNode?.dispose();
    emailTextController?.dispose();

    contactNumbersFocusNode?.dispose();
    contactNumbersTextController?.dispose();
  }
}
