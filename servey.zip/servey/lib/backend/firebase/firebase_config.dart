import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyA3Kz-7zKUsgSxwSJI7rY8_9X-VNC8NyVY",
            authDomain: "surveying-f205f.firebaseapp.com",
            projectId: "surveying-f205f",
            storageBucket: "surveying-f205f.appspot.com",
            messagingSenderId: "626271577703",
            appId: "1:626271577703:web:f7eaf88a7488429037d6c2",
            measurementId: "G-DPE01B3D7Y"));
  } else {
    await Firebase.initializeApp();
  }
}
