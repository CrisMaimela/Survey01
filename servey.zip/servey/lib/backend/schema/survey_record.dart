import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SurveyRecord extends FirestoreRecord {
  SurveyRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "fullNames" field.
  String? _fullNames;
  String get fullNames => _fullNames ?? '';
  bool hasFullNames() => _fullNames != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "DOB" field.
  DateTime? _dob;
  DateTime? get dob => _dob;
  bool hasDob() => _dob != null;

  // "Age" field.
  int? _age;
  int get age => _age ?? 0;
  bool hasAge() => _age != null;

  // "ContactNo" field.
  String? _contactNo;
  String get contactNo => _contactNo ?? '';
  bool hasContactNo() => _contactNo != null;

  // "favouriteFood" field.
  List<String>? _favouriteFood;
  List<String> get favouriteFood => _favouriteFood ?? const [];
  bool hasFavouriteFood() => _favouriteFood != null;

  // "MovieRate" field.
  int? _movieRate;
  int get movieRate => _movieRate ?? 0;
  bool hasMovieRate() => _movieRate != null;

  // "RadioRate" field.
  int? _radioRate;
  int get radioRate => _radioRate ?? 0;
  bool hasRadioRate() => _radioRate != null;

  // "OutRate" field.
  int? _outRate;
  int get outRate => _outRate ?? 0;
  bool hasOutRate() => _outRate != null;

  // "tvRate" field.
  int? _tvRate;
  int get tvRate => _tvRate ?? 0;
  bool hasTvRate() => _tvRate != null;

  void _initializeFields() {
    _fullNames = snapshotData['fullNames'] as String?;
    _email = snapshotData['email'] as String?;
    _dob = snapshotData['DOB'] as DateTime?;
    _age = castToType<int>(snapshotData['Age']);
    _contactNo = snapshotData['ContactNo'] as String?;
    _favouriteFood = getDataList(snapshotData['favouriteFood']);
    _movieRate = castToType<int>(snapshotData['MovieRate']);
    _radioRate = castToType<int>(snapshotData['RadioRate']);
    _outRate = castToType<int>(snapshotData['OutRate']);
    _tvRate = castToType<int>(snapshotData['tvRate']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Survey');

  static Stream<SurveyRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SurveyRecord.fromSnapshot(s));

  static Future<SurveyRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SurveyRecord.fromSnapshot(s));

  static SurveyRecord fromSnapshot(DocumentSnapshot snapshot) => SurveyRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SurveyRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SurveyRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SurveyRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SurveyRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSurveyRecordData({
  String? fullNames,
  String? email,
  DateTime? dob,
  int? age,
  String? contactNo,
  int? movieRate,
  int? radioRate,
  int? outRate,
  int? tvRate,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'fullNames': fullNames,
      'email': email,
      'DOB': dob,
      'Age': age,
      'ContactNo': contactNo,
      'MovieRate': movieRate,
      'RadioRate': radioRate,
      'OutRate': outRate,
      'tvRate': tvRate,
    }.withoutNulls,
  );

  return firestoreData;
}

class SurveyRecordDocumentEquality implements Equality<SurveyRecord> {
  const SurveyRecordDocumentEquality();

  @override
  bool equals(SurveyRecord? e1, SurveyRecord? e2) {
    const listEquality = ListEquality();
    return e1?.fullNames == e2?.fullNames &&
        e1?.email == e2?.email &&
        e1?.dob == e2?.dob &&
        e1?.age == e2?.age &&
        e1?.contactNo == e2?.contactNo &&
        listEquality.equals(e1?.favouriteFood, e2?.favouriteFood) &&
        e1?.movieRate == e2?.movieRate &&
        e1?.radioRate == e2?.radioRate &&
        e1?.outRate == e2?.outRate &&
        e1?.tvRate == e2?.tvRate;
  }

  @override
  int hash(SurveyRecord? e) => const ListEquality().hash([
        e?.fullNames,
        e?.email,
        e?.dob,
        e?.age,
        e?.contactNo,
        e?.favouriteFood,
        e?.movieRate,
        e?.radioRate,
        e?.outRate,
        e?.tvRate
      ]);

  @override
  bool isValidKey(Object? o) => o is SurveyRecord;
}
