import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FavouriteFoodRecord extends FirestoreRecord {
  FavouriteFoodRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Food" field.
  String? _food;
  String get food => _food ?? '';
  bool hasFood() => _food != null;

  void _initializeFields() {
    _food = snapshotData['Food'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('FavouriteFood');

  static Stream<FavouriteFoodRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FavouriteFoodRecord.fromSnapshot(s));

  static Future<FavouriteFoodRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FavouriteFoodRecord.fromSnapshot(s));

  static FavouriteFoodRecord fromSnapshot(DocumentSnapshot snapshot) =>
      FavouriteFoodRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FavouriteFoodRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FavouriteFoodRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FavouriteFoodRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FavouriteFoodRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFavouriteFoodRecordData({
  String? food,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Food': food,
    }.withoutNulls,
  );

  return firestoreData;
}

class FavouriteFoodRecordDocumentEquality
    implements Equality<FavouriteFoodRecord> {
  const FavouriteFoodRecordDocumentEquality();

  @override
  bool equals(FavouriteFoodRecord? e1, FavouriteFoodRecord? e2) {
    return e1?.food == e2?.food;
  }

  @override
  int hash(FavouriteFoodRecord? e) => const ListEquality().hash([e?.food]);

  @override
  bool isValidKey(Object? o) => o is FavouriteFoodRecord;
}
