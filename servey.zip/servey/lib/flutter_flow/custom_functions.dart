import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

int getAgeMethod(DateTime dob) {
  // Determine age by using the Date and Time
  final now = DateTime.now();
  final age = now.year - dob.year;
  if (now.month < dob.month || (now.month == dob.month && now.day < dob.day)) {
    return age - 1;
  }
  return age;
}

int? averageAge(List<int> age) {
  // Get average age
  if (age.isEmpty) {
    return null;
  }
  final sum = age.reduce((a, b) => a + b);
  return (sum / age.length).round();
}

int? getOldestPerson(List<int>? age) {
  // Get maximum age
  if (age == null || age.isEmpty) {
    return null;
  }
  return age.reduce(math.max);
}

int? getMinAge(List<int>? age) {
  // Get minimum age
// Get minimum age
  if (age == null || age.isEmpty) {
    return null;
  }
  return age.reduce(math.min);
}

String? getPizzaPercentage(
  List<String>? food,
  String? name,
) {
  // Get percentage by counting food items with same name dividing by total number of food
  if (food == null || name == null) {
    return null;
  }
  final count = food.where((item) => item == name).length;
  final percentage = (count / food.length) * 100;
  return '${percentage.toStringAsFixed(1)}%';
}

int? getRatingAverage(List<int>? rating) {
  // Determine the average rating round results to one decimal
// Get average rating
  if (rating == null || rating.isEmpty) {
    return null;
  }
  final sum = rating.reduce((a, b) => a + b);
  final average = sum / rating.length;
  return average.roundToDouble().toInt();
}
