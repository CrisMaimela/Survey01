import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  bool _moviesSA = false;
  bool get moviesSA => _moviesSA;
  set moviesSA(bool _value) {
    _moviesSA = _value;
  }

  bool _moviesA = false;
  bool get moviesA => _moviesA;
  set moviesA(bool _value) {
    _moviesA = _value;
  }

  bool _moviesN = false;
  bool get moviesN => _moviesN;
  set moviesN(bool _value) {
    _moviesN = _value;
  }

  bool _moviesD = false;
  bool get moviesD => _moviesD;
  set moviesD(bool _value) {
    _moviesD = _value;
  }

  bool _moviesSD = false;
  bool get moviesSD => _moviesSD;
  set moviesSD(bool _value) {
    _moviesSD = _value;
  }

  bool _radioSA = false;
  bool get radioSA => _radioSA;
  set radioSA(bool _value) {
    _radioSA = _value;
  }

  bool _radioA = false;
  bool get radioA => _radioA;
  set radioA(bool _value) {
    _radioA = _value;
  }

  bool _radioN = false;
  bool get radioN => _radioN;
  set radioN(bool _value) {
    _radioN = _value;
  }

  bool _radioD = false;
  bool get radioD => _radioD;
  set radioD(bool _value) {
    _radioD = _value;
  }

  bool _radioSD = false;
  bool get radioSD => _radioSD;
  set radioSD(bool _value) {
    _radioSD = _value;
  }

  bool _outSA = false;
  bool get outSA => _outSA;
  set outSA(bool _value) {
    _outSA = _value;
  }

  bool _outA = false;
  bool get outA => _outA;
  set outA(bool _value) {
    _outA = _value;
  }

  bool _outN = false;
  bool get outN => _outN;
  set outN(bool _value) {
    _outN = _value;
  }

  bool _outD = false;
  bool get outD => _outD;
  set outD(bool _value) {
    _outD = _value;
  }

  bool _outSD = false;
  bool get outSD => _outSD;
  set outSD(bool _value) {
    _outSD = _value;
  }

  bool _tvSA = false;
  bool get tvSA => _tvSA;
  set tvSA(bool _value) {
    _tvSA = _value;
  }

  bool _tvA = false;
  bool get tvA => _tvA;
  set tvA(bool _value) {
    _tvA = _value;
  }

  bool _tvN = false;
  bool get tvN => _tvN;
  set tvN(bool _value) {
    _tvN = _value;
  }

  bool _tvD = false;
  bool get tvD => _tvD;
  set tvD(bool _value) {
    _tvD = _value;
  }

  bool _tvSD = false;
  bool get tvSD => _tvSD;
  set tvSD(bool _value) {
    _tvSD = _value;
  }

  String _Movies = '';
  String get Movies => _Movies;
  set Movies(String _value) {
    _Movies = _value;
  }

  String _Radio = '';
  String get Radio => _Radio;
  set Radio(String _value) {
    _Radio = _value;
  }

  String _OUT = '';
  String get OUT => _OUT;
  set OUT(String _value) {
    _OUT = _value;
  }

  String _TV = '';
  String get TV => _TV;
  set TV(String _value) {
    _TV = _value;
  }

  String _foodPizza = '';
  String get foodPizza => _foodPizza;
  set foodPizza(String _value) {
    _foodPizza = _value;
  }

  String _foodPasta = '';
  String get foodPasta => _foodPasta;
  set foodPasta(String _value) {
    _foodPasta = _value;
  }

  String _foodPapWors = '';
  String get foodPapWors => _foodPapWors;
  set foodPapWors(String _value) {
    _foodPapWors = _value;
  }

  String _foodOther = '';
  String get foodOther => _foodOther;
  set foodOther(String _value) {
    _foodOther = _value;
  }

  bool _foodPi = false;
  bool get foodPi => _foodPi;
  set foodPi(bool _value) {
    _foodPi = _value;
  }

  bool _foodPa = false;
  bool get foodPa => _foodPa;
  set foodPa(bool _value) {
    _foodPa = _value;
  }

  bool _foodPW = false;
  bool get foodPW => _foodPW;
  set foodPW(bool _value) {
    _foodPW = _value;
  }

  bool _foodO = false;
  bool get foodO => _foodO;
  set foodO(bool _value) {
    _foodO = _value;
  }

  List<String> _FOODTYPELIST = [];
  List<String> get FOODTYPELIST => _FOODTYPELIST;
  set FOODTYPELIST(List<String> _value) {
    _FOODTYPELIST = _value;
  }

  void addToFOODTYPELIST(String _value) {
    _FOODTYPELIST.add(_value);
  }

  void removeFromFOODTYPELIST(String _value) {
    _FOODTYPELIST.remove(_value);
  }

  void removeAtIndexFromFOODTYPELIST(int _index) {
    _FOODTYPELIST.removeAt(_index);
  }

  void updateFOODTYPELISTAtIndex(
    int _index,
    String Function(String) updateFn,
  ) {
    _FOODTYPELIST[_index] = updateFn(_FOODTYPELIST[_index]);
  }

  void insertAtIndexInFOODTYPELIST(int _index, String _value) {
    _FOODTYPELIST.insert(_index, _value);
  }

  int _MoviesRate = 0;
  int get MoviesRate => _MoviesRate;
  set MoviesRate(int _value) {
    _MoviesRate = _value;
  }

  int _RadioRate = 0;
  int get RadioRate => _RadioRate;
  set RadioRate(int _value) {
    _RadioRate = _value;
  }

  int _OutRate = 0;
  int get OutRate => _OutRate;
  set OutRate(int _value) {
    _OutRate = _value;
  }

  int _tvRate = 0;
  int get tvRate => _tvRate;
  set tvRate(int _value) {
    _tvRate = _value;
  }
}
